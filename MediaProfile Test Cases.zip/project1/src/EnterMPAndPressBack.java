import java.time.Duration;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
public class EnterMPAndPressBack {
    public static void main(String[] args) throws InterruptedException {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\admin\\Downloads\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
        MediaProfile mp = new MediaProfile();
        try {
            mp.signIN(driver);
            mp.configuration(driver);
            boolean enterMP = mp.enterMediaProfileAndPressBack(driver,"media1");
            assert enterMP;
        }
        catch (InterruptedException e) {
            System.out.println(e);
        } finally {
            mp.cleanUp(driver);
            mp.logOut(driver);

        }
    }
}

