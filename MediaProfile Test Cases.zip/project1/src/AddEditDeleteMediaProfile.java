import java.time.Duration;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
public class AddEditDeleteMediaProfile {
    public static void main(String[] args) throws InterruptedException {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\admin\\Downloads\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
        MediaProfile mp = new MediaProfile();
        try{
            mp.signIN(driver);
            mp.configuration(driver);
            boolean success = mp.addMediaProfile(driver,"media1","subName1","load1");
            assert success;
            boolean editMedia =mp.editMedia(driver,"media1","media2","subName1","subName2");
            assert editMedia;
            boolean delete= mp.deleteMedia(driver,"media2","subName2");
            assert delete;
        }
        finally {
            mp.cleanUp(driver);
            mp.logOut(driver);

        }
    }
}
